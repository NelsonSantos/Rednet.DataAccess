using System;

namespace Rednet.DataAccess
{


    //public interface IFieldDefinition
    //{
    //    string Name { get; set; }
    //    bool IsPrimaryKey { get; set; }
    //    AutomaticValue AutomaticValue { get; set; }
    //    bool IsNullAble { get; set; }
    //    Type DotNetType { get; set; }
    //    int Lenght { get; set; }
    //    int Precision { get; set; }
    //}
}