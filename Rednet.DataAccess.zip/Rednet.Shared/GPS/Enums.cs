namespace Rednet.Shared.GPS
{
    public enum GMapV2DirectionReturnType
    {
        Xml,
        Json
    }

    public enum GMapV2DirectionMode
    {
        Driving,
        Walking
    }
}