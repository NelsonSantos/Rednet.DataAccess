namespace Rednet.Shared.GPS
{
    public class Bounds
    {
        public Location Northeast { get; set; }
        public Location Southwest { get; set; }
    }
}