namespace Rednet.Shared.GPS
{
    public class Distance
    {
        public string Text { get; set; }
        public int Value { get; set; }
    }
}