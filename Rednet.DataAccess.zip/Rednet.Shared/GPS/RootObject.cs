using System.Collections.Generic;

namespace Rednet.Shared.GPS
{
    public class RootObject
    {
        public List<Route> Routes { get; set; }
        public string Status { get; set; }
    }
}