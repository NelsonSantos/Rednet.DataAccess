namespace Rednet.Shared.GPS
{
    public class Duration
    {
        public string Text { get; set; }
        public int Value { get; set; }
    }
}