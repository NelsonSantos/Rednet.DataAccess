namespace Rednet.Shared.GPS
{
    public class Polyline
    {
        public string Points { get; set; }
    }
}