namespace Rednet.Shared.GPS
{
    public class OverviewPolyline
    {
        public string Points { get; set; }
    }
}